<?php
/**
 * Plugin Name: Lastic Productions Downloader
 * Plugin URI: https://lasticproductions.com
 * Description: Embed the Lastic Productions video downloader into WordPress
 * Version: 1.0.0
 * Author: Lastic Productions
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class LasticDownloader {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    public function init() {
        add_shortcode('lastic_downloader', array($this, 'render_downloader'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
    }
    
    public function enqueue_scripts() {
        wp_enqueue_style('lastic-downloader-style', plugins_url('assets/style.css', __FILE__));
        wp_enqueue_script('lastic-downloader-script', plugins_url('assets/script.js', __FILE__), array('jquery'), '1.0.0', true);
    }
    
    public function render_downloader($atts) {
        $atts = shortcode_atts(array(
            'url' => '',
            'height' => '600px',
            'width' => '100%',
            'theme' => 'dark'
        ), $atts);
        
        $app_url = get_option('lastic_downloader_url', 'http://127.0.0.1:5000');
        
        ob_start();
        ?>
        <div class="lastic-downloader-container" data-theme="<?php echo esc_attr($atts['theme']); ?>">
            <div class="lastic-downloader-header">
                <h3>📥 Video Downloader</h3>
                <p>Download videos from YouTube and other platforms</p>
            </div>
            
            <div class="lastic-downloader-iframe-wrapper">
                <iframe 
                    src="<?php echo esc_url($app_url); ?>" 
                    width="<?php echo esc_attr($atts['width']); ?>" 
                    height="<?php echo esc_attr($atts['height']); ?>" 
                    frameborder="0"
                    allowfullscreen
                    class="lastic-downloader-iframe">
                </iframe>
            </div>
            
            <div class="lastic-downloader-footer">
                <small>Powered by <a href="https://lasticproductions.com" target="_blank">Lastic Productions</a></small>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    public function add_admin_menu() {
        add_options_page(
            'Lastic Downloader Settings',
            'Lastic Downloader',
            'manage_options',
            'lastic-downloader',
            array($this, 'admin_page')
        );
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>⚙️ Lastic Downloader Settings</h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('lastic_downloader_settings'); ?>
                <?php do_settings_sections('lastic_downloader_settings'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="lastic_downloader_url">App URL</label>
                        </th>
                        <td>
                            <input 
                                type="url" 
                                id="lastic_downloader_url" 
                                name="lastic_downloader_url" 
                                value="<?php echo esc_attr(get_option('lastic_downloader_url', 'http://127.0.0.1:5000')); ?>" 
                                class="regular-text"
                                placeholder="https://your-app-url.com"
                            />
                            <p class="description">
                                Enter the URL where your Flask app is hosted (e.g., https://your-app.herokuapp.com)
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="lastic_downloader_default_height">Default Height</label>
                        </th>
                        <td>
                            <input 
                                type="text" 
                                id="lastic_downloader_default_height" 
                                name="lastic_downloader_default_height" 
                                value="<?php echo esc_attr(get_option('lastic_downloader_default_height', '600px')); ?>" 
                                class="regular-text"
                            />
                            <p class="description">
                                Default iframe height for the downloader
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="lastic_downloader_theme">Default Theme</label>
                        </th>
                        <td>
                            <select 
                                id="lastic_downloader_theme" 
                                name="lastic_downloader_theme" 
                                class="regular-text">
                                <option value="dark" <?php selected(get_option('lastic_downloader_theme', 'dark'), 'dark'); ?>>Dark</option>
                                <option value="light" <?php selected(get_option('lastic_downloader_theme', 'dark'), 'light'); ?>>Light</option>
                            </select>
                            <p class="description">
                                Choose the default theme for the downloader
                            </p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button('Save Settings'); ?>
            </form>
            
            <div class="card">
                <h2>📖 Usage Instructions</h2>
                <h3>Shortcode Usage:</h3>
                <code>[lastic_downloader]</code>
                
                <h3>Custom Parameters:</h3>
                <ul>
                    <li><code>url="https://your-app.com"</code> - Override app URL</li>
                    <li><code>height="800px"</code> - Custom height</li>
                    <li><code>width="100%"</code> - Custom width</li>
                    <li><code>theme="light"</code> - Light theme</li>
                </ul>
                
                <h3>Example:</h3>
                <code>[lastic_downloader url="https://your-app.herokuapp.com" height="800px" theme="light"]</code>
            </div>
        </div>
        <?php
    }
}

// Initialize the plugin
new LasticDownloader();

// Register settings
function latic_downloader_register_settings() {
    register_setting('lastic_downloader_settings', 'lastic_downloader_url');
    register_setting('lastic_downloader_settings', 'lastic_downloader_default_height');
    register_setting('lastic_downloader_settings', 'lastic_downloader_theme');
}
add_action('admin_init', 'latic_downloader_register_settings');

// Helper function for selected option
function selected($current, $option) {
    return ($current == $option) ? 'selected="selected"' : '';
}
?>
